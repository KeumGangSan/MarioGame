package com.s409022mg.mario;

public enum Id {
	player, wall;
}
